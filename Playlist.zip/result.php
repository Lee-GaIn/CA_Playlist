<html>
<body>
  <?php
    include 'get-params.php';
    $_playlist = $_POST['selectedPlaylist'];

    switch($_playlist) {
      case "playlist1":
        include playlist1.php;
        break;

      case "playlist2":
        include playlist2.php;
        break;
    }
  ?>
</body>
</html>