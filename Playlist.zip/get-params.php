<?php
  require 'php.phar';
  session_start();

  echo("session before", $_SESSION)

  $_SESSION['endPoint'] = "myplaylist.cdjbpaylhk6s.us-east-1.rds.amazonaws.com";
  $_SESSION['userName'] = "admin";
  $_SESSION['pwd'] = "lab-password";
  $_SESSION['dbName'] = "MyPlaylist";

  echo("session after", $_SESSION)

  // $ssm_client = new Aws\Ssm\SsmClient([
  //   'region' => 'us-east-1',
  //   'version' => 'latest'
  // ]);

  // $result = $ssm_client->GetParametersByPath(['Path' => '/MyPlaylist/']);

  // console.log($result)

  // foreach($result['Parameters'] as $p) {
  //     $values[$p['Name']] = $p['Value'];
  // }

  // $_SESSION['endPoint'] = $values['/MyPlaylist/endPoint'];
  // $_SESSION['userName'] = $values['/MyPlaylist/userName'];
  // $_SESSION['pwd'] = $values['/MyPlaylist/pwd'];
  // $_SESSION['dbName'] = $values['/MyPlaylist/dbName'];
?>
