<?php
  error_log('Retrieving settings');
  require 'php.phar';
  session_start();

  $_SESSION['endPoint'] = "myplaylist.c0oixhywfsrz.us-east-1.rds.amazonaws.com";
  $_SESSION['userName'] = "admin";
  $_SESSION['pwd'] = "lab-password";
  $_SESSION['dbName'] = "MyPlaylist";

  // $ssm_client = new Aws\Ssm\SsmClient([
  //   'region' => 'us-east-1',
  //   'version' => 'latest'
  // ]);

  // $result = $ssm_client->GetParametersByPath(['Path' => '/MyPlaylist/']);

  // console.log($result)

  // foreach($result['Parameters'] as $p) {
  //     $values[$p['Name']] = $p['Value'];
  // }

  // $_SESSION['endPoint'] = $values['/MyPlaylist/endPoint'];
  // $_SESSION['userName'] = $values['/MyPlaylist/userName'];
  // $_SESSION['pwd'] = $values['/MyPlaylist/pwd'];
  // $_SESSION['dbName'] = $values['/MyPlaylist/dbName'];
?>
