<a href="index.php">Pick another playlist</a>

<?php
  $cmd = "select name,singer from myplaylist1;";
  $connection = new mysqli($_SESSION['endPoint'], $_SESSION['userName'], $_SESSION['pwd'], $_SESSION['dbName']);
  if ($connection->connect_error) {
    print_r($connection->connect_error);
  }
  else {
  $res = $conn->query($cmd);
  print_r($res)
  if ($res->num_rows > 0) {

      echo '<table style="width: 80%">';
      echo '<tr>';
      echo '<th style="text-align:left">Song name</th>';
      echo '<th style="text-align:left">Artist</th>';
      echo '</tr>';

      while($row = $res->fetch_assoc()) {

      echo '<tr>';
      echo '<td>';
      echo $row["name"];
      echo '&nbsp';
      echo '<td>';
      echo $row["singer"];
      echo '&nbsp';
      echo '<br>';
      echo '</tr>';
      }
      echo '</table>';
    }
  }
?>