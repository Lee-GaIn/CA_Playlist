<a href="index.php">Pick another playlist</a>
<h4>===playlist 2===</h4>
<?php
  $sql = "SELECT name, singer FROM myplaylist1;";
  $link = mysqli_connect($_SESSION['endPoint'], $_SESSION['userName'], $_SESSION['pwd'], $_SESSION['dbName']);
  $res = mysqli_query($link, $sql);

  while($row = mysqli_fetch_array($res)) {
    echo $row.'<br>';
  };

  $sql = "SELECT name, singer FROM myplaylist2;";
  $connect = mysqli_connect($_SESSION['endPoint'], $_SESSION['userName'], $_SESSION['pwd'], $_SESSION['dbName']);
  mysqli_select_db($connect, $_SESSION['dbName']) or die('DB fail!');

  $result = mysqli_query($connect, $sql);

  while($info=mysqli_fetch_array($result)){
      print_r(info);
      echo "/n";
  }
  mysqli_close($connect);
?>